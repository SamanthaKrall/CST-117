﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KrallSamantha_Exercise3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles;
            double gallons;
            double mpg;
            miles = double.Parse(milesTB.Text);
            gallons = double.Parse(gasTB.Text);
            mpg = miles / gallons;
            calculationLabel.Text = mpg.ToString("n3");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            calculationLabel.Text = " ";
            milesTB.Text = " ";
            gasTB.Text = " ";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
